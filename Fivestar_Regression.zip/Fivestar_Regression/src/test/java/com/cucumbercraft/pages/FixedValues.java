package com.cucumbercraft.pages;

public class FixedValues {

	public static int LHRTaxValue = 0;
	public static int NRTTaxValue = 0;
	public static double OverrideAmount=200;
	
	public static String CarCompany = "BMW";
	public static String CarPhone = "8123374616";
	public static String DriverName = "Shruti";
	public static String DriverPhone = "8427174715";
	public static String ATOComments = "Book Car";
}
