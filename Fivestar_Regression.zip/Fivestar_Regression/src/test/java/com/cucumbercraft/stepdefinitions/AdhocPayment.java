package com.cucumbercraft.stepdefinitions;



public class AdhocPayment {

	public String testCase;
	
	public ReqInitiation ReqInitiation;
	
	public class ReqInitiation{
		public String RequestNo;
		public String AirportCode;
		public String timetoSet;
		public String AdultNo;
		public String ChildNo;
		public String AdultNames;
		public String ChildNames;
	}
	
	

}
